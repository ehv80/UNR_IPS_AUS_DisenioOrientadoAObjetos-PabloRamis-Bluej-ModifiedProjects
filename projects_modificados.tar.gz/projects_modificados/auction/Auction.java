import java.util.ArrayList;
import java.util.Iterator;

/**
 * A simple model of an auction.
 * The auction maintains a list of lots of arbitrary length.
 * ----------------------------------------------------------------------------
 * Un modelo simple de una subasta (Auction). Esta subasta mantiene una lista 
 * de lotes (Lot) de longitud arbitraria.
 * ----------------------------------------------------------------------------
 * @author David J. Barnes and Michael Kolling.
 * @version 2003.10.06
 */
public class Auction
{
    // The list of Lots in this auction.
    private ArrayList lots;
    // The number that will be given to the next lot entered
    // into this auction.
    private int nextLotNumber;

    /**
     * Create a new auction.
     * ------------------------------------------------------------------------
     * Constructor de esta clase Auction. No recibe par�metros. Instancia un
     * nuevo objeto de la clase ArrayList e inicializa "nextLotNumber" en uno.
     * ------------------------------------------------------------------------
     */
    public Auction()
    {
        lots = new ArrayList();
        nextLotNumber = 1;
    }

    /**
     * Enter a new lot into the auction.
     * Lots can only by entered into the auction by an
     * Auction object.
     * ------------------------------------------------------------------------
     * M�todo que toma como par�metro una cadena de caracteres "description" y 
     * no retorna nada (void). Sirve para ingresar un lote dentro de la subasta.
     * Los lotes solo pueden ser ingresados dentro de la subasta por un objeto
     * de esta clase Auction.
     * En este m�todo se crean "objetos an�nimos" de la clase Lot que se van 
     * agregando dentro del ArrayList denominado "lots", no es necesario saber
     * sus nombres pues se accede a ellos a traves de un �ndice del ArrayList.
     * ------------------------------------------------------------------------
     * @param description A description of the lot.
     */
    public void enterLot(String description)
    {
        lots.add(new Lot(nextLotNumber, description));  //objeto an�nimo de Lot 
        nextLotNumber++;                                
    }

    /**
     * Show the full list of lots in this auction.
     * ------------------------------------------------------------------------
     * Muestra la lista entera de lotes de esta subasta.
     * ------------------------------------------------------------------------
     */
    public void showLots()
    {
        Iterator it = lots.iterator();
        while(it.hasNext()) {
            Lot lot = (Lot) it.next();
            System.out.println(lot.toString());
        }
    }
    /* ------------------------------------------------------------------------
     * Ejercicio 4.22 de la p�gina 96: El ejemplo de uso de casting se puede
     * encontrar dentro del m�todo "showLots()" de esta clase "Auction" en la
     * l�nea que contiene:      Lot lot = (Lot) it.next();                    
     * ------------------------------------------------------------------------*/
    
    /* ------------------------------------------------------------------------
     * Ejercicio 4.23 de la p�gina 96: Al quitar el casting al m�todo 
     * "showLots()" sucede un error en tiempo de compilaci�n:
     *  "incompatible types - found java.lang.Object but expected Lot"
     *  que significa "tipos incompatibles - encontrado java.lang.Object pero
     *  esperado Lot".
     * ------------------------------------------------------------------------*/ 
    
    /**
     * Bid for a lot.
     * A message indicating whether the bid is successful or not
     * is printed.
     * ------------------------------------------------------------------------
     * Una oferta (Bid) para un lote.
     * Retorna un mensaje que indica si la oferta es satisfactoria o no.
     * Este m�todo toma como par�metros un entero "lotNumber", un objeto de la
     * clase Person "bidder" que representa al oferente y un entero largo 
     * "value" que representa el valor de la oferta.
     * Nuevamente se crea un "objeto an�nimo" de la clase Lot
     * ------------------------------------------------------------------------
     * @param number The lot number being bid for.
     * @param bidder The person bidding for the lot.
     * @param value  The value of the bid.
     */
    public void bidFor(int lotNumber, Person bidder, long value)
    {
        Lot selectedLot = getLot(lotNumber);
        if(selectedLot != null) {
            if(selectedLot.bidFor(new Bid(bidder, value))) { //objeto an�nimo
                System.out.println("The bid for lot number " +
                                   lotNumber + " was successful.");
            }
            else {
                System.out.println("Lot number: " + lotNumber +
                                   " already has a bid of: " +
                                   selectedLot.getHighestBid().getValue());
            }
        }
    }

    /**
     * Return the lot with the given number. Return null
     * if a lot with this number does not exist.
     * -------------------------------------------------------------------------
     * M�todo que toma como par�metro un entero "lotNumber" que representa al 
     * n�mero identificatorio de un lote( tener en cuenta que 
     * 1 <= lotNumber < nextLotNumber ). Busca en el ArrayList "lots" por un 
     * lote que tenga ese n�mero, si lo encuentra retorna ese lote, de lo 
     * contrario retorna "null" ( tener en cuenta que
     * 0 <= indice del ArrayList < lots.size() ).
     * -------------------------------------------------------------------------
     * @param lotNumber The number of the lot to return.
     */
    public Lot getLot(int lotNumber)
    {
        for( int i=0 ; i < lots.size() ; i++ )
        {
            Lot temp = ( Lot ) lots.get( i );
            if( temp != null && temp.getNumber() == lotNumber )
            {
                return temp;
            }
        }
        return null;
        
        /*
        * if((lotNumber >= 1) && (lotNumber < nextLotNumber)) {
        *    //The number seems to be reasonable.
        *    //Lot selectedLot = (Lot) lots.get(lotNumber - 1 );
        *    //Include a confidence check to be sure we have the
        *    //right lot.
        *    if(selectedLot.getNumber() != lotNumber) {
        *        System.out.println("Internal error: " +
        *                           "Wrong lot returned. " +
        *                           "Number: " + lotNumber);
        *    }
        *    return selectedLot;
        *}
        *else {
        *    System.out.println("Lot number: " + lotNumber +
        *                       " does not exist.");
        *    return null;
        *}
        */
    }
    
    /*  ------------------------------------------------------------------------
     * Ejercicio 4.26 de la p�gina 97.
     * Si esta clase "Auction" incluyera un m�todo que hiciera posible remover 
     * un lote del ArrayList "lots" sin que se modifiquen los campos "number"
     * de los lotes restantes, indudablemente afectar�a en el funcionamiento 
     * correcto del m�todo "getLot( int LotNumber )" pues al haber un lote menos
     * y al realizar:  "Lot selectedLot = (Lot) lots.get(lotNumber - 1);"
     * estar�a obteniendo un lote distinto al que en realidad se est� pidiendo. 
     *  ------------------------------------------------------------------------*/
     
    /*  ------------------------------------------------------------------------
     * Ejercicio 4.27 de la p�gina 97.
     * Modificaci�n del m�todo "public Lot getLot(int lotNumber)". Se reescribe
     * este m�todo as� no depende de un lote con un n�mero particular que est�
     * siendo almacenado en la posici�n (number - 1) en la collecci�n. Por 
     * ejemplo, si el lote con n�mero 2 ha sido removido, entonces el lote 
     * n�mero 3 ser� movido desde la posici�n con �ndice 2 hacia la posici�n
     * con �ndice 1, y todos los lotes con n�meros mayores tambi�n ser�n
     * movidos en una posici�n hacia atr�s. Se asume que los lotes est�n
     * siempre almacenados en orden creciente de sus n�meros.
     * Para obtener este comportamineto utilizo un bucle "for" para
     * 0 <= i < lots.size() donde en cada iteraci�n guarda el lote de esa 
     * posici�n "i" con "Lot temp = ( Lot ) lots.get( i );" y me fijo si
     * "temp.getNumber() == lotNumber" entonces retorno ese lote "temp".
     * De lo contrario si ha recorrido todo el ArrayList de lotes sin encontrar
     * un lote con su n�mero igual a "lotNumber" retorno "null".
     *  ------------------------------------------------------------------------*/
     
    /** ------------------------------------------------------------------------
     * Borra el Lote con el n�mero dado.
     * @param number El n�mero del lote a ser removido.
     * @return El lote con el n�mero dado, o null si no hay lote con ese n�mero.
     *  ------------------------------------------------------------------------
     * Ejercicio 4.28 de la p�gina 97.
     * M�todo requerido para poder remover un lote del ArrayList "lots". Este 
     * m�todo asume que un lote con un "number" dado se almacena en cualquier 
     * posici�n dentro de la colecci�n.
     *  ------------------------------------------------------------------------**/
     public Lot removeLot( int number )
     {
         for( int i=0 ; i < lots.size() ; i++ )
         {
             Lot temp = ( Lot ) lots.get( i );
             if( temp != null && temp.getNumber() == number )
             {
                 lots.remove( i );
                 return temp;
             }
         }
         return null;
     }
    
    /** ------------------------------------------------------------------------
     * M�todo requerido por el ejercicio 4.24 de la p�gina 97.
     * Itera sobre toda la colecci�n de lotes e imprime en pantalla el detalle
     * de cada uno de los lotes. Un lote que ha tenido al menos una oferta se lo
     * considera vendido. Para los lotes considerados como vendidos el detalle 
     * debe incluir el nombre del oferente y el valor de esa oferta ganadora.
     * Para los lotes que no han sido vendidos, se imprime un mensaje que indica
     * este hecho.
     * La iteraci�n sobre cada elemento del ArrayList se realiza mediante un 
     * objeto de la clase Iterator denominado "iterador". Para cada uno de esos
     * elementos que son objetos de la clase Lot se realiza una serie de 
     * verificaciones a trav�s de un "if": se fija si ese Lot es distinto de 
     * "null" y si el objeto de la clase Bid obtenido con "temp.getHighestBid()"
     * es distinto de "null" y si el objeto de la clase Person obtenido con
     * "temp.getHighestBid().getBidder()" es distinto de "null" y si el valor de
     * la oferta obtenido con "temp.getHighestBid().getValue() != 0" y si el
     * nombre del oferente obtenido con 
     * "temp.getHighestBid().getBidder().getName()" es distinto de "null" 
     * entonces la cadena de caracteres "detalle" contendr� el n�mero, la 
     * descripci�n, el valor de la oferta y el nombre del oferente.
     * De lo contrario la cadena de caracteres "detalle" solo contendr� el
     * n�mero, la descripci�n y un mensaje que indica que no ha tenido ofertas.
     *  ------------------------------------------------------------------------**/
     public void close()
     {
         Iterator iterador = lots.iterator();
         while( iterador.hasNext() )
         {
             Lot temp = ( Lot ) iterador.next();
             String detalle = "";
             if( temp != null && temp.getHighestBid() != null 
                 && temp.getHighestBid().getBidder() != null
                 && temp.getHighestBid().getValue() != 0
                 && temp.getHighestBid().getBidder().getName() != null )
             {
                     detalle += temp.toString() + " cuyo oferente es : " 
                                + temp.getHighestBid().getBidder().getName();
             }
             else
             {
                     detalle += temp.toString() 
                                + " el cu�l no ha tenido ofertas hasta ahora.";
             }
             System.out.println( detalle );
         }
     }
     
    /** ------------------------------------------------------------------------
     * M�todo requerido por el ejercicio 4.25 de la p�gina 97.
     * Itera sobre cada uno de los Lots del ArrayList denominado "lots" en busca
     * de lotes que no han tenido ofertas. Si el lote no ha tenido ofertas ( es
     * decir, si el lote "temp" es distinto de "null" y si el objeto de la clase
     * Bid obtenido con "temp.getHighestBid()" es igual a "null") entonces se lo
     * guarda en un ArrayList temporal denominado "aux". Cuando termina la
     * iteraci�n sobre todos los lotes del ArrayList "lots" retorna el ArrayList
     * "aux" con todos aquellos lotes que no han tenido ofertas.
     *  ------------------------------------------------------------------------**/
     public ArrayList getUnsold()
     {
         ArrayList aux = new ArrayList();
         Iterator iterador = lots.iterator();
         while( iterador.hasNext() )
         {
             Lot temp = (Lot) iterador.next();
             if( temp != null && temp.getHighestBid() == null )
             {
                 aux.add( temp );
             }
         }
         return aux;
     }
     
    /** ------------------------------------------------------------------------
     * Itera sobre cada uno de los lotes del ArrayList denominado "lots" en 
     * busca de lotes que han sido vendidos, es decir, que han tenido ofertas.
     * Si el lote ha tenido ofertas (es decir, si el lote "temp" es distinto de
     * "null" y si el objeto de la clase Bid obtenido con "temp.getHighestBid()"
     * es distinto de "null") entonces se lo guarda en un ArrayList temporal 
     * denominado "aux". Cuando termina la iteraci�n sobre todos los lotes del
     * ArrayList "lots" retorna el ArrayList "aux" que contendr� todos aquellos 
     * lotes que han tenido ofertas.
     *  ------------------------------------------------------------------------**/
     public ArrayList getSold()
     {
         ArrayList aux = new ArrayList();
         Iterator iterador = lots.iterator();
         while( iterador.hasNext() )
         {
             Lot temp = (Lot) iterador.next();
             if( temp != null && temp.getHighestBid() != null )
             {
                 aux.add( temp );
             }
         }
         return aux;
     }
    
    /** ------------------------------------------------------------------------
     * M�todo requerido por el ejercicio para entregar, denominado "sorteo()". A
     * trav�s del azar elige uno de los lotes que tiene oferta y lo muestra en 
     * pantalla. Se utiliza un ArrayList temporal denominado "ofertados" que 
     * contiene el resultado retornado por el m�todo "getSold()", es decir, el 
     * ArrayList "ofertados" posee solo aquellos lotes que poseen ofertas.
     * Se elige uno de los lotes que hay en "ofertados" de manera aleatoria y 
     * se muestra la descripci�n de ese lote elegido al azar, o en su defecto
     * un mensaje que informa que ninguno de los lotes ha sido beneficiado por
     * el sorteo.
     *  ------------------------------------------------------------------------**/
     public void sorteo()
     {
         ArrayList ofertados = getSold();
         
         int min = 0, max = ofertados.size(), rango = max - min;
         int aleat = 1 + min + ( int )( rango * Math.random() );
         if( aleat >= 0 && aleat < max )
         {
             String detalle = "El lote que ha sido beneficiado por este sorteo es: ";
             detalle += (( Lot ) ofertados.get( aleat )).toString();
             detalle += " cuyo oferente es: ";
             detalle += (( Lot ) ofertados.get( aleat )).getHighestBid().getBidder().getName();
             System.out.println( detalle );
         }
         else
         {
             System.out.println("Ning�n lote ha sido beneficiado por este sorteo!!!");
         }
     }
 }