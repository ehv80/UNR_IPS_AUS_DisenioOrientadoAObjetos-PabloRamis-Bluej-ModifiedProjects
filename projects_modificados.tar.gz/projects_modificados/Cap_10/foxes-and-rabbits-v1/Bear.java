import java.util.List;
import java.util.Iterator;

/**
 * Bear (Oso): Tipo específico de Animal.
 * Un oso puede comer tanto a conejos como a zorros.
 * 
 * @author Ezequiel Hernán Villanueva 
 * @version 08.01.2006
 */
public class Bear extends Animal
{
    // variables y constantes de clase (static)
    // The age at which a fox can start to breed.
    private static final int BREEDING_AGE = 14;
    // The age to which a fox can live.
    private static final int MAX_AGE = 175;
    // The likelihood of a fox breeding.
    private static final double BREEDING_PROBABILITY = 0.07;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 4;
    // The food value of a single rabbit. In effect, this is the
    // number of steps a fox can go before it has to eat again.
    private static final int RABBIT_FOOD_VALUE = 6;
    // number of steps a fox can go before it has to eat again.
    private static final int FOX_FOOD_VALUE = 1;

    // variables y constantes de instancia
    private int foodLevel;
    
    
    /**
     * Create a bear. A bear can be created as a new born (age zero
     * and not hungry) or with random age.
     * 
     * @param randomAge If true, the bear will have random age and hunger level.
     */
    public Bear( boolean randomAge )
    {
        super.setAge(0);
        super.setAlive(true);
        if(randomAge) {
            super.setAge( super.getRand().nextInt(MAX_AGE) );
            foodLevel = super.getRand().nextInt( RABBIT_FOOD_VALUE + FOX_FOOD_VALUE );
        }
        else {
            // leave age at 0
            foodLevel = ( RABBIT_FOOD_VALUE + FOX_FOOD_VALUE );
        }
    }
    
    // métodos de clase (static)
    
    //métodos de instancia
    
   /**
     * This is what the bear does most of the time: it hunts for
     * rabbits or fox. In the process, it might breed, die of hunger,
     * or die of old age.
     * @param currentField The field currently occupied.
     * @param updatedField The field to transfer to.
     * @param newFoxes A list to add newly born foxes to.
     */
    public void act(Field currentField, Field updatedField, List newBears)
    {
        incrementAge();
        incrementHunger();
        if( super.getAlive() ) {
            // New bears are born into adjacent locations.
            int births = breed();
            for(int b = 0; b < births; b++) {
                Bear newBear = new Bear(false);
                newBears.add(newBear);
                Location loc = updatedField.randomAdjacentLocation( super.getLocation() );
                newBear.setLocation(loc);
                updatedField.place(newBear, loc);
            }
            // Move towards the source of food if found.
            Location newLocation = findFood(currentField, super.getLocation() );
            if(newLocation == null) {  // no food found - move randomly
                newLocation = updatedField.freeAdjacentLocation( super.getLocation() );
            }
            if(newLocation != null) {
                setLocation(newLocation);
                updatedField.place(this, newLocation);
            }
            else {
                // can neither move nor stay - overcrowding - all locations taken
                super.setAlive(false);
            }
        }
    } 

    /**
     * Make this fox more hungry. This could result in the fox's death.
     */
    private void incrementHunger()
    {
        foodLevel--;
        if(foodLevel <= 0) {
            super.setAlive(false);
        }
    }
    
    /**
     * Tell the bear to look for rabbits or foxs adjacent to its current location.
     * @param field The field in which it must look.
     * @param location Where in the field it is located.
     * @return Where food was found, or null if it wasn't.
     */
    private Location findFood(Field field, Location location)
    {
        Iterator adjacentLocations = field.adjacentLocations(location);
        while(adjacentLocations.hasNext())
        {   Location where = (Location) adjacentLocations.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof Rabbit)
            {   Rabbit rabbit = (Rabbit) animal;
                if( rabbit.getAlive() )
                {   rabbit.setDeath();
                    foodLevel = RABBIT_FOOD_VALUE;
                    return where;
                }
            }
            if(animal instanceof Fox)
            {   Fox fox = (Fox) animal;
                if( fox.getAlive() )
                {   fox.setDeath();
                    foodLevel = FOX_FOOD_VALUE;
                    return where;
                }
            } 
        }
        return null;
    }
    
    /** Retorna la edad de reproducción para un oso. 
     * @return   BREEDING_AGE
     */
    public int getBreedingAge(){ return BREEDING_AGE; }
    
    /** Retorna el valor de la probilidad de reproducción de 
     * un oso.
     * @return   BREEDING_PROBABILITY
     */
     public double getBreedingProbability(){ return BREEDING_PROBABILITY; }
     
     /** Retorna el número máximo de nacimientos para el oso.
      * @return   MAX_LITTER_SIZE
      */
     public int getMaxLitterSize(){ return MAX_LITTER_SIZE; }
     
      /** Retorna la edad máxima que puede alcanzar un oso.
      * @return   MAX_AGE
      */
     public int getMaxAge(){ return MAX_AGE; }
}