import java.util.List;
import java.util.Iterator;

/**
 * A simple model of a fox.
 * Foxes age, move, eat rabbits, and die.
 * 
 * @author David J. Barnes and Michael Kolling
 * @version 2002.10.28
 */
public class Fox extends Animal
{
    // Characteristics shared by all foxes (static fields).
    
    // The age at which a fox can start to breed.
    private static final int BREEDING_AGE = 10;
    // The age to which a fox can live.
    private static final int MAX_AGE = 150;
    // The likelihood of a fox breeding.
    private static final double BREEDING_PROBABILITY = 0.09;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 3;
    // The food value of a single rabbit. In effect, this is the
    // number of steps a fox can go before it has to eat again.
    private static final int RABBIT_FOOD_VALUE = 4;

    private int foodLevel;

    /**
     * Create a fox. A fox can be created as a new born (age zero
     * and not hungry) or with random age.
     * 
     * @param randomAge If true, the fox will have random age and hunger level.
     */
    public Fox(boolean randomAge)
    {
        super.setAge(0);
        super.setAlive(true);
        if(randomAge) {
            super.setAge( super.getRand().nextInt(MAX_AGE) );
            foodLevel = super.getRand().nextInt(RABBIT_FOOD_VALUE);
        }
        else {
            // leave age at 0
            foodLevel = RABBIT_FOOD_VALUE;
        }
    }
       
   /**
     * This is what the fox does most of the time: it hunts for
     * rabbits. In the process, it might breed, die of hunger,
     * or die of old age.
     * @param currentField The field currently occupied.
     * @param updatedField The field to transfer to.
     * @param newFoxes A list to add newly born foxes to.
     */
    public void act(Field currentField, Field updatedField, List newFoxes)
    {
        incrementAge();
        incrementHunger();
        if( super.getAlive() ) {
            // New foxes are born into adjacent locations.
            int births = breed();
            for(int b = 0; b < births; b++) {
                Fox newFox = new Fox(false);
                newFoxes.add(newFox);
                Location loc = updatedField.randomAdjacentLocation( super.getLocation() );
                newFox.setLocation(loc);
                updatedField.place(newFox, loc);
            }
            // Move towards the source of food if found.
            Location newLocation = findFood(currentField, super.getLocation() );
            if(newLocation == null) {  // no food found - move randomly
                newLocation = updatedField.freeAdjacentLocation( super.getLocation() );
            }
            if(newLocation != null) {
                setLocation(newLocation);
                updatedField.place(this, newLocation);
            }
            else {
                // can neither move nor stay - overcrowding - all locations taken
                super.setAlive(false);
            }
        }
    }

   /**
     * Make this fox more hungry. This could result in the fox's death.
     */
    private void incrementHunger()
    {
        foodLevel--;
        if(foodLevel <= 0) {
            super.setAlive(false);
        }
    }
    
    /**
     * Tell the fox to look for rabbits adjacent to its current location.
     * @param field The field in which it must look.
     * @param location Where in the field it is located.
     * @return Where food was found, or null if it wasn't.
     */
    private Location findFood(Field field, Location location)
    {
        Iterator adjacentLocations =
                          field.adjacentLocations(location);
        while(adjacentLocations.hasNext()) {
            Location where = (Location) adjacentLocations.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof Rabbit) {
                Rabbit rabbit = (Rabbit) animal;
                if( rabbit.getAlive() ) { 
                    rabbit.setDeath();
                    foodLevel = RABBIT_FOOD_VALUE;
                    return where;
                }
            }
        }
        return null;
    }
    
    /** Retorna la edad de reproducción para un ZORRO. 
     * @return   BREEDING_AGE
     */
    public int getBreedingAge(){ return BREEDING_AGE; }
    
    /** Retorna el valor de la probilidad de reproducción de 
     * un zorro.
     * @return   BREEDING_PROBABILITY
     */
     public double getBreedingProbability(){ return BREEDING_PROBABILITY; }
     
     /** Retorna el número máximo de nacimientos para el zorro.
      * @return   MAX_LITTER_SIZE
      */
     public int getMaxLitterSize(){ return MAX_LITTER_SIZE; }
     
      /** Retorna la edad máxima que puede alcanzar un zorro.
      * @return   MAX_AGE
      */
     public int getMaxAge(){ return MAX_AGE; }
}