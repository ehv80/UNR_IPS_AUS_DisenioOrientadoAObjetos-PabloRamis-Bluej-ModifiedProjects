import java.util.Collections;
import java.awt.Color;
import java.util.Random;
import java.util.List;
/**
 * Clase Requerida por el ejercicio 10.34 de la pag. 286.
 * Genera el estado de la población inicial en la simulación.
 * 
 * @author Ezequiel Hernán Villanueva 
 * @version 07.01.2006
 */
public class PopulationGenerator
{
    // variables y constantes de clase (static)
    // The probability that a bear will be created in any given grid position.
    private static final double BEAR_CREATION_PROBABILITY = 0.012;
    // The probability that a fox will be created in any given grid position.
    private static final double FOX_CREATION_PROBABILITY = 0.02;
    // The probability that a rabbit will be created in any given grid position.
    private static final double RABBIT_CREATION_PROBABILITY = 0.08;    
    
    // variables y constantes de instancia
    private SimulatorView view;
    private Random rand;
        
    /**
     * Constructor for objects of class PopulationGenerator
     */
    public PopulationGenerator(int depth, int width)
    {
        rand = new Random();
        view = new SimulatorView(depth, width);
        view.setColor(Bear.class, Color.darkGray);
        view.setColor(Fox.class, Color.blue);
        view.setColor(Rabbit.class, Color.orange);
    }

    // métodos de clase (static)
        
    // métodos de instancia
    public void setView( SimulatorView otraView ){ view = otraView;}  
    public SimulatorView getView(){ return view; }
    
    /**
     * Populate a field with foxes and rabbits.
     * @param field The field to be populated.
     * @param    actors   La lista de particpantes en la simulación.
     */
    public void populate(Field field , List actors )
    {
        field.clear();
        for(int row = 0; row < field.getDepth(); row++) {
            for(int col = 0; col < field.getWidth(); col++) {
                if(rand.nextDouble() <= BEAR_CREATION_PROBABILITY) {
                    Bear bear = new Bear(true);
                    //Fox fox = new Fox(false);  //Ejercicio 10.16 pag. 279
                    actors.add(bear);
                    bear.setLocation(row, col);
                    field.place(bear, row, col);
                }
                else if(rand.nextDouble() <= FOX_CREATION_PROBABILITY) {
                    Fox fox = new Fox(true);
                    //Fox fox = new Fox(false);  //Ejercicio 10.16 pag. 279
                    actors.add(fox);
                    fox.setLocation(row, col);
                    field.place(fox, row, col);
                }
                else if(rand.nextDouble() <= RABBIT_CREATION_PROBABILITY) {
                    Rabbit rabbit = new Rabbit(true); // Ejercicio 10.17 pag. 279
                    //Rabbit rabbit = new Rabbit(false); //Ejercicio 10.16 pag. 279
                    actors.add(rabbit);
                    rabbit.setLocation(row, col);
                    field.place(rabbit, row, col);
                }
                // else leave the location empty.
            }
        }
        Collections.shuffle(actors);
    }
}    