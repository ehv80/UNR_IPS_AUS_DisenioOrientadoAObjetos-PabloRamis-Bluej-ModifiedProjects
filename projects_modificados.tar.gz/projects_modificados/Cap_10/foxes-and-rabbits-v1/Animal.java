import java.util.Random;
import java.util.List;
/**
 * Abstract class Animal
 * 
 * @author Ezequiel Hernán Villanueva
 * @version 29.12.2005
 */
public abstract class Animal implements Actor
{
    // variables y constantes de clase (static)
    private static final Random rand = new Random();
    
    //variables y constantes de instancia???
    private int age;
    private boolean alive;
    private Location location;
    
    /** Una clase abstracta no necesita definir constructor */
        
    //métodos de clase (static)
    public static Random getRand(){ return rand; }
        
    // métodos de instancia???
    public void setAge( int otraEdad ){ age = otraEdad; }
    public int getAge(){ return age; }
    
    /** Indica que un Animal muere */
    public void setDeath(){ alive = false; }
    public void setAlive( boolean vof ){ alive = vof; }
    public boolean getAlive(){ return alive; }
        
    /** Set the Animal's location.
     * @param row The vertical coordinate of the location.
     * @param col The horizontal coordinate of the location. */
    public void setLocation(int row, int col)
    {
        this.location = new Location(row, col);
    }
    /** Set the fox's location.
     * @param location The fox's location.  */
    public void setLocation(Location location)
    {
        this.location = location;
    }
    public Location getLocation(){ return location; }
    
    /** Un Animal puede reproducirse cuando ha alcanzado su edad de 
     * Reproducción.     
     * @return   true   Si ha alcanzado la edad de reproducción.*/
     public boolean canBreed(){ return ( age >= getBreedingAge() ); }
     
     /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    public int breed()
    {
        int births = 0;
        if(canBreed() && ( getRand().nextDouble() <= getBreedingProbability() ) ) {
            births = ( getRand().nextInt( getMaxLitterSize() ) + 1 );
        }
        return births;
    }
    
    /** Increase the age. This could result in the Animal's death.
     */
    public void incrementAge()
    {
        setAge( getAge() + 1 ) ;
        if( getAge() > getMaxAge() )
        {   setAlive(false);
        }
    }
    
    //métodos abstractos
    
    /** Indica que un Animal actúe, pero al no saber que tipo específico de
     * Animal será el que actúe, no se especifica implementación alguna.
     * Es por esto que este debe ser sobre-escrito en todas las SUB-CLASES
     * para que cada tipo específico de Animal actúe a su manera.
     * @param   currentField   El campo (Field) actualmente ocupado
     * @param   updatedField   El campo (Field) al que se transfiere
     * @param   newAnimals     Una lista en la que se agregan los animales recién nacidos.
     */
     abstract public void act( Field currentField , Field updatedField , List newAnimals );
     
     /** Retorna la edad de reproducción para el animal. Al no saber qué tipo específico de
      * Animal es, este método es sin lugar a dudas abstracto, debiéndo ser redefinidos 
      * en todas las SUB-CLASES de Animal, tanto en Fox como en Rabbit.
      * @return   BREEDING_AGE
      */
     abstract public int getBreedingAge();
     
     /** Retorna el valor de la probabilidad de reproducción para el Animal.
      * Nuevamente al no saber que tipo específico de Animal es, el método es
      * abstracto.
      * @return   BREEDING_PROBABILITY
      */
     abstract public double getBreedingProbability();
     
     /** Retorna el número máximo de nacimientos para el Animal.
      * @return   MAX_LITTER_SIZE
      */
     abstract public int getMaxLitterSize();
     
     /** Retorna la edad máxima que puede alcanzar un Animal.
      * @return   MAX_AGE
      */
     abstract public int getMaxAge();
}
