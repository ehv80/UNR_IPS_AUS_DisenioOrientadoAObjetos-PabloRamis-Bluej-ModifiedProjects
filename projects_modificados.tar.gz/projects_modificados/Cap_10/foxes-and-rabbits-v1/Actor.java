import java.util.List;
/**
 * Interface Actor: representa a un participante de la simulación,
 * independientemente del tipo específico que sea.
 * El agregado de esta interface permite posible extensiones futuras como ser,
 * ingresar humanos, plantas, o el clima en la simulación, simplemente haciendo.
 * que hereden de esta interface.
 * 
 * @author Ezequiel Hernán Villanueva
 * @version 10.01.2006
 */
public interface Actor
{
	/**
	 * La acción que realiza el participante de la simulación.
	 * Es un método abstracto porque no sabemos con precisión 
	 * a qué SUB-TIPO específico pertenece el Actor.
	 * Debe ser sobre-escrito en todas las SUB-CLASES.
	 * Las interfaces de por sí solo contienen firmas de métodos 
	 * abstractos sin su implementeación(sin cuerpos de métodos).
	 * Si poseen atributos solo se permite que sean public static final
	 * (constantes de Clase)auque no hay necesidad de aclararlo.
	 * 
	 * @param   currentField   El campo donde está
	 * @param   updatedField   El campo hacia el que se mueve
	 * @param   newAnimals   Lista de los animales recién nacidos
	 */
	abstract public void act( Field currentField, Field updatedField, List newAnimals);
}
