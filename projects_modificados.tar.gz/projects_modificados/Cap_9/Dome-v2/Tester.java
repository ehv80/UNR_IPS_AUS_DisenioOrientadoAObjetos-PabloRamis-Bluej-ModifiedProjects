
/**
 * Clase de Testeo.
 * Dos alternativas : realiza todo en el contructor, o bién
 * desde el método main()
 * @author Ezequiel Hernán Villanueva
 * @version 25.12.2005
 */
public class Tester
{
    // instance variables - replace the example below with your own
    //private int x;

    /**
     * Constructor for objects of class Tester
     * Alternativa uno: instanciaciones y llamadas a métodos en 
     * Constructor.
     */
    public Tester()
    {
        Database db = new Database();
        
        CD cd1 = new CD( "Millenium", "BackStreet Boys" , 12 , 65 );
        Video vid1 = new Video( "Sin City", "Robert Rodriguez" , 120 );
        
        cd1.setOwn( true );
        cd1.setComment( "What a fucking CD!!!");

        vid1.setOwn( true );
        vid1.setComment("What a bloodiest movie!!!");
        
        db.addItem( cd1 );
        db.addItem( vid1 );
        
        db.list();
        System.out.println( cd1 );
        System.out.println( vid1 );
        
        System.out.println("---FIN---");
    }

}
